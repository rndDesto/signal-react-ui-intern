
  

# Signal React Ui Milestones Ideas & Examples

  

  

Project management milestones ideas and examples.

  

  

Contents:

  

* [Button](#Button)

  

* [Card](#Card)

* [Snackbar](#Overlay)

* [Chips](#Navigation)

* [Callout](#Overlay)

* [Typography](#Typography)

  

  

### Button

Button - [Link](https://gitlab.com/rndDesto/signal-react-ui-intern/-/milestones/1) [Zikri]

  

### Layout

Card - [Link](https://gitlab.com/rndDesto/signal-react-ui-intern/-/milestones/5)

  

### Overlay

Callout - [Link](https://gitlab.com/rndDesto/signal-react-ui-intern/-/milestones/4)  [Agil]

Snackbar - [Link](https://gitlab.com/rndDesto/signal-react-ui-intern/-/milestones/6)

### Navigation

Chips - [Link](https://gitlab.com/rndDesto/signal-react-ui-intern/-/milestones/3)[Nadhifa]

### Typography

Typography - [Link](https://gitlab.com/rndDesto/signal-react-ui-intern/-/milestones/2)


### Commit Message 
[Nama_Developer-Nama_Komponen]Message yang dicommit
git commit -m "[Desto-Card]inisial komit komponen card"

### Branch_Name
[Nama_Developer] Nama_Branch
[Desto] Develop_Componen_Card
