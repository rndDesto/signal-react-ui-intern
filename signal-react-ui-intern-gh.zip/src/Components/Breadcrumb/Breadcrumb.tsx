
const Breadcrumb = () => {
  return (
    <div>Breadcrumb</div>
  )
}

export default Breadcrumb