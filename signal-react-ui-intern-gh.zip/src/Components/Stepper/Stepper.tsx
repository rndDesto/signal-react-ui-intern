
export const Stepper = () => {
  return (
    <div>
        <h1>Headingnya stepper</h1>
        <div>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quod ullam veritatis ex. Vel perferendis aperiam quisquam voluptas voluptate optio non cum asperiores tempora neque! Maxime sit necessitatibus rerum reprehenderit. Voluptatibus.</div>
    </div>
  )
}
