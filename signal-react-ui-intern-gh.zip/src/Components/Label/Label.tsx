
const Label = () => {
  return (
    <div>Label</div>
  )
}

export default Label