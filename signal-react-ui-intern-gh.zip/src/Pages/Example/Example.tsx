
const Example = () => {
  return (
    <div>Example mantul</div>
  )
}

export default Example